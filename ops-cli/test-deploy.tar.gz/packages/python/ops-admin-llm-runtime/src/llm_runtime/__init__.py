"""LLM runtime bounded context."""
