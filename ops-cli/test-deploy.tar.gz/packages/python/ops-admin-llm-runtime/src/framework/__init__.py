"""Framework-level reusable capabilities."""
