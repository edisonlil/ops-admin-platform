"""Appearance bounded context."""
