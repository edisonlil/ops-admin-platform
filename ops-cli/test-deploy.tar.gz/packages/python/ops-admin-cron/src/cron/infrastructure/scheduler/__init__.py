"""Scheduler adapters for cron."""
