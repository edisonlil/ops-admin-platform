"""Cron infrastructure adapters."""
