"""Cron persistence adapters."""
