"""Cron bounded context."""
