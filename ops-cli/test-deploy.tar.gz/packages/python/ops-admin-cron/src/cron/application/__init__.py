"""Cron application services."""
