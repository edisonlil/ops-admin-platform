"""Cron domain model."""
