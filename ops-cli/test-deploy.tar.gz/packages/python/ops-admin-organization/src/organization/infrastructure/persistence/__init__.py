"""Organization persistence."""
