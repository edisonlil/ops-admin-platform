"""Organization bounded context."""
