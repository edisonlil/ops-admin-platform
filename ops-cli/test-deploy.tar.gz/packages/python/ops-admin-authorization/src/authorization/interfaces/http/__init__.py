"""Authorization HTTP interfaces."""
