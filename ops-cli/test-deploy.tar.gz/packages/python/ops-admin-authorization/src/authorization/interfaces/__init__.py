"""Authorization interfaces."""
