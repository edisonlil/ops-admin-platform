"""Authorization application services."""
