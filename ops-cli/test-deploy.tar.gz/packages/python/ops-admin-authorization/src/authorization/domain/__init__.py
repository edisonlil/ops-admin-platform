"""Authorization domain."""
