"""Authorization bounded context."""
