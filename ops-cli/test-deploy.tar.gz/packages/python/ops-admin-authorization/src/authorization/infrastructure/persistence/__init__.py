"""Authorization persistence."""
