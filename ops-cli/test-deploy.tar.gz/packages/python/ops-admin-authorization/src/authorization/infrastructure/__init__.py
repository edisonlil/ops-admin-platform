"""Authorization infrastructure."""
