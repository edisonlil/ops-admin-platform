"""Basic data infrastructure adapters."""
