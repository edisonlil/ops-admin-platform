"""Basic data persistence adapters."""
