"""Basic data domain model."""
