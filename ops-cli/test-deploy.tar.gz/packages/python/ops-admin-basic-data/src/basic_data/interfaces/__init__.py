"""Basic data interface adapters."""
