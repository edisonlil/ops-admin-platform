"""Basic data HTTP interface."""
