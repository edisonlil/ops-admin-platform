"""Basic data bounded context."""
