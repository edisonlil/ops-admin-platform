"""Basic data application services."""
