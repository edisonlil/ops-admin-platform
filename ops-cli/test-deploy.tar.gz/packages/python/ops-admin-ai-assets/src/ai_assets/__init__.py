"""AI assets bounded context."""
