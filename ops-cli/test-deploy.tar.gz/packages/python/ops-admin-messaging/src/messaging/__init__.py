"""Messaging bounded context."""
