"""Messaging domain model."""
