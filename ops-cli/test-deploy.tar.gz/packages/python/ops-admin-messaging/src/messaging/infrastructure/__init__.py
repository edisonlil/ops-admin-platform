"""Messaging infrastructure adapters."""
