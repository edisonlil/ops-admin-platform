"""Messaging persistence."""
