"""Messaging application services."""
