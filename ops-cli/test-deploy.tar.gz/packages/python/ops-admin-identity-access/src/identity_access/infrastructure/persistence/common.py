from __future__ import annotations

import threading
from datetime import datetime
from typing import Any

from fastapi import HTTPException, status

from identity_access.infrastructure.config import (
    auth_database_target,
    default_admin_password,
    default_admin_username,
)
from identity_access.infrastructure.persistence.bootstrap import ensure_identity_schema, ensure_identity_seed
from identity_access.infrastructure.security import hash_password
from system.infrastructure.persistence.dialect import add_column_if_missing, backend_name, column_exists, index_exists, table_exists
from system.infrastructure.persistence.connection import connect


PLATFORM_TENANT_KEY = "platform"
DEFAULT_TENANT_KEY = "default"
DEFAULT_ROLE_KEY = "admin"

_auth_schema_lock = threading.Lock()


AUTH_INIT_COMMAND = "python scripts/init_identity_access.py"


class DisabledUserException(HTTPException):
    def __init__(self) -> None:
        super().__init__(status_code=status.HTTP_403_FORBIDDEN, detail="user is disabled")


DEFAULT_MENU_METADATA: dict[str, dict[str, str]] = {
    "messaging": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "message-inbox": {"menu_type": "page", "component": "/messaging/inbox/index", "menu_scope": "tenant"},
    "message-inbox-read": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-inbox-unread": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-inbox-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-outbox": {"menu_type": "page", "component": "/messaging/outbox/index", "menu_scope": "tenant"},
    "message-outbox-cancel": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-send": {"menu_type": "page", "component": "/messaging/send/index", "menu_scope": "tenant"},
    "message-send-submit": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-templates": {"menu_type": "page", "component": "/messaging/templates/index", "menu_scope": "tenant"},
    "message-templates-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-templates-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-templates-enable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-templates-disable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-channels": {"menu_type": "page", "component": "/messaging/channels/index", "menu_scope": "tenant"},
    "message-channels-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-channels-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-channels-enable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-channels-disable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "message-channels-test": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "file-management": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "file-libraries": {"menu_type": "page", "component": "/files/libraries/index", "menu_scope": "tenant"},
    "file-libraries-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "file-libraries-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "file-libraries-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "file-objects": {"menu_type": "page", "component": "/files/objects/index", "menu_scope": "tenant"},
    "file-objects-upload": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "file-objects-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "file-storage-profiles": {"menu_type": "page", "component": "/files/storage-profiles/index", "menu_scope": "platform"},
    "file-storage-profiles-manage": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "file-preview-profiles": {"menu_type": "page", "component": "/files/preview-profiles/index", "menu_scope": "platform"},
    "file-preview-profiles-manage": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "file-tenant-quotas": {"menu_type": "page", "component": "/files/tenant-quotas/index", "menu_scope": "platform"},
    "file-tenant-quotas-manage": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "ai-tenant-quotas": {"menu_type": "page", "component": "/ai/tenant-quotas/index", "menu_scope": "platform"},
    "ai-tenant-quotas-manage": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "basic-data": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "basic-data-dictionaries": {"menu_type": "page", "component": "/basic-data/dictionaries/index", "menu_scope": "tenant"},
    "basic-data-dictionaries-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-dictionaries-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-dictionaries-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-items-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-items-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-items-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-regions": {"menu_type": "page", "component": "/basic-data/regions/index", "menu_scope": "tenant"},
    "basic-data-regions-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-regions-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-regions-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "basic-data-regions-import": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "cron": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "cron-tasks": {"menu_type": "page", "component": "/cron/tasks/index", "menu_scope": "tenant"},
    "cron-tasks-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "cron-tasks-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "cron-tasks-enable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "cron-tasks-disable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "cron-tasks-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "cron-tasks-trigger": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "cron-runs": {"menu_type": "page", "component": "/cron/runs/index", "menu_scope": "tenant"},
    "llm": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "llm-config": {"menu_type": "page", "component": "/settings/llm-config/index", "menu_scope": "tenant"},
    "llm-providers-save": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "llm-models-save": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "llm-tasks-register": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "llm-routing-policies-save": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "llm-debug": {"menu_type": "page", "component": "/settings/llm-debug/index", "menu_scope": "tenant"},
    "llm-debug-send": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio": {"menu_type": "page", "component": "/ai/studio/index", "menu_scope": "tenant"},
    "ai-studio-app-read": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio-app-manage": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio-app-publish": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio-app-run": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio-capability-read": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio-capability-manage": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio-capability-execute": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-studio-trace-read": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "ai-assets": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "prompt-library": {"menu_type": "page", "component": "/prompts/library/index", "menu_scope": "tenant"},
    "prompt-library-manage": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "tenant-settings": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "tenant-user-management": {"menu_type": "page", "component": "/tenant/index", "menu_scope": "tenant"},
    "tenant-users-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "tenant-users-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "tenant-users-enable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "tenant-users-disable": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "tenant-api-keys": {"menu_type": "page", "component": "/settings/api-keys/index", "menu_scope": "tenant"},
    "tenant-api-keys-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "tenant-api-keys-revoke": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "organization": {"menu_type": "directory", "component": "", "menu_scope": "tenant"},
    "organization-departments": {"menu_type": "page", "component": "/organization/departments/index", "menu_scope": "tenant"},
    "organization-departments-create": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "organization-departments-update": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "organization-departments-delete": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "data-scope-management": {"menu_type": "page", "component": "/authorization/data-scope/index", "menu_scope": "tenant"},
    "data-scope-management-read": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "data-scope-management-manage": {"menu_type": "action", "component": "", "menu_scope": "tenant"},
    "platform-management": {"menu_type": "directory", "component": "", "menu_scope": "platform"},
    "platform-branding": {"menu_type": "page", "component": "/platform/index", "menu_scope": "platform"},
    "platform-branding-update": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management": {"menu_type": "page", "component": "/tenant/index", "menu_scope": "platform"},
    "tenant-management-create": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-update": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-activate": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-suspend": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-users-create": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-users-update": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-api-keys-create": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-api-keys-revoke": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "tenant-management-theme-assign": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "appearance-studio": {"menu_type": "page", "component": "/settings/appearance-studio/index", "menu_scope": "platform"},
    "appearance-themes-create": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "appearance-themes-update": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "appearance-themes-publish": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "appearance-themes-disable": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "appearance-themes-set-default": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "rbac": {"menu_type": "directory", "component": "", "menu_scope": "platform"},
    "user-management": {"menu_type": "page", "component": "/rbac/user/index", "menu_scope": "platform"},
    "user-management-create": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "user-management-update": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "user-management-enable": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "user-management-disable": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "menu-management": {"menu_type": "page", "component": "/rbac/menu/index", "menu_scope": "platform"},
    "menu-management-create": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "menu-management-update": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "menu-management-delete": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "role-management": {"menu_type": "page", "component": "/rbac/role/index", "menu_scope": "platform"},
    "role-management-create": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "role-management-update": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "role-management-delete": {"menu_type": "action", "component": "", "menu_scope": "platform"},
    "role-management-assign-menus": {"menu_type": "action", "component": "", "menu_scope": "platform"},
}

TENANT_MESSAGING_MENU_KEYS = [
    "messaging",
    "message-inbox",
    "message-inbox-read",
    "message-inbox-unread",
    "message-inbox-delete",
    "message-outbox",
    "message-outbox-cancel",
    "message-send",
    "message-send-submit",
    "message-templates",
    "message-templates-create",
    "message-templates-update",
    "message-templates-enable",
    "message-templates-disable",
    "message-channels",
    "message-channels-create",
    "message-channels-update",
    "message-channels-enable",
    "message-channels-disable",
    "message-channels-test",
]
TENANT_MESSAGING_NAV_MENU_KEYS = [
    "messaging",
    "message-inbox",
    "message-outbox",
    "message-send",
    "message-templates",
    "message-channels",
]
TENANT_FILE_MENU_KEYS = [
    "file-management",
    "file-libraries",
    "file-libraries-create",
    "file-libraries-update",
    "file-libraries-delete",
    "file-objects",
    "file-objects-upload",
    "file-objects-delete",
]
TENANT_FILE_NAV_MENU_KEYS = [
    "file-management",
    "file-libraries",
    "file-objects",
]
TENANT_BASIC_DATA_MENU_KEYS = [
    "basic-data",
    "basic-data-dictionaries",
    "basic-data-dictionaries-create",
    "basic-data-dictionaries-update",
    "basic-data-dictionaries-delete",
    "basic-data-items-create",
    "basic-data-items-update",
    "basic-data-items-delete",
    "basic-data-regions",
    "basic-data-regions-create",
    "basic-data-regions-update",
    "basic-data-regions-delete",
    "basic-data-regions-import",
]
TENANT_BASIC_DATA_NAV_MENU_KEYS = [
    "basic-data",
    "basic-data-dictionaries",
    "basic-data-regions",
]
TENANT_LLM_MENU_KEYS = [
    "llm",
    "llm-config",
    "llm-providers-save",
    "llm-models-save",
    "llm-tasks-register",
    "llm-routing-policies-save",
    "llm-debug",
    "llm-debug-send",
]
TENANT_CRON_MENU_KEYS = [
    "cron",
    "cron-tasks",
    "cron-tasks-create",
    "cron-tasks-update",
    "cron-tasks-enable",
    "cron-tasks-disable",
    "cron-tasks-delete",
    "cron-tasks-trigger",
    "cron-runs",
]
TENANT_AI_ASSETS_MENU_KEYS = [
    "ai-studio",
    "ai-studio-app-read",
    "ai-studio-app-manage",
    "ai-studio-app-publish",
    "ai-studio-app-run",
    "ai-studio-capability-read",
    "ai-studio-capability-manage",
    "ai-studio-capability-execute",
    "ai-studio-trace-read",
    "ai-assets",
    "prompt-library",
    "prompt-library-manage",
]
TENANT_AI_ASSETS_NAV_MENU_KEYS = [
    "ai-studio",
    "ai-assets",
    "prompt-library",
]
TENANT_ORGANIZATION_MENU_KEYS = [
    "organization",
    "organization-departments",
    "organization-departments-create",
    "organization-departments-update",
    "organization-departments-delete",
    "data-scope-management",
    "data-scope-management-read",
    "data-scope-management-manage",
]
TENANT_ORGANIZATION_NAV_MENU_KEYS = [
    "organization",
    "organization-departments",
    "data-scope-management",
]
RETIRED_AI_ASSETS_MENU_KEYS = [
    "prompt-contracts",
    "prompt-contracts-manage",
    "prompt-bindings",
    "prompt-bindings-manage",
    "prompt-runs",
]
RETIRED_AI_ASSETS_PERMISSION_CODES = [
    "prompt:contracts:manage",
    "prompt:bindings:manage",
    "prompt:runs:view",
]
TENANT_ADMIN_MENU_KEYS = (
    [
        "tenant-settings",
        "tenant-user-management",
        "tenant-users-create",
        "tenant-users-update",
        "tenant-users-enable",
        "tenant-users-disable",
        "tenant-api-keys",
        "tenant-api-keys-create",
        "tenant-api-keys-revoke",
    ]
    + TENANT_MESSAGING_MENU_KEYS
    + TENANT_FILE_MENU_KEYS
    + TENANT_BASIC_DATA_MENU_KEYS
    + TENANT_LLM_MENU_KEYS
    + TENANT_CRON_MENU_KEYS
    + TENANT_AI_ASSETS_MENU_KEYS
    + TENANT_ORGANIZATION_MENU_KEYS
)
TENANT_MEMBER_MENU_KEYS = ["tenant-settings"]
DEFAULT_TENANT_ENABLED_MENU_KEYS = (
    ["tenant-settings", "tenant-user-management", "tenant-api-keys"]
    + TENANT_MESSAGING_NAV_MENU_KEYS
    + TENANT_FILE_NAV_MENU_KEYS
    + TENANT_BASIC_DATA_NAV_MENU_KEYS
    + TENANT_LLM_MENU_KEYS
    + ["cron", "cron-tasks", "cron-runs"]
    + TENANT_AI_ASSETS_NAV_MENU_KEYS
    + TENANT_ORGANIZATION_NAV_MENU_KEYS
)
TENANT_ADMIN_EXTRA_PERMISSION_CODES = [
    "llm_config:update",
    "llm:providers:save",
    "llm:models:save",
    "llm:tasks:register",
    "llm:routing_policies:save",
    "llm_debug:send",
    "ai_applications:read",
    "ai_applications:manage",
    "ai_applications:publish",
    "ai_applications:run",
    "ai_capabilities:read",
    "ai_capabilities:manage",
    "ai_capabilities:execute",
    "ai_runtime:trace:read",
    "ai_studio:quota:read",
    "tenant:users:create",
    "tenant:users:update",
    "tenant:users:enable",
    "tenant:users:disable",
    "tenant:user:manage",
    "tenant:api_keys:create",
    "tenant:api_keys:revoke",
    "organization:departments:read",
    "organization:departments:manage",
    "authorization:data-scope:read",
    "authorization:data-scope:manage",
    "messaging:inbox:view",
    "messaging:inbox:manage_self",
    "messaging:messages:view",
    "messaging:messages:send",
    "messaging:messages:cancel",
    "messaging:templates:view",
    "messaging:templates:create",
    "messaging:templates:update",
    "messaging:templates:enable",
    "messaging:templates:disable",
    "messaging:channels:view",
    "messaging:channels:create",
    "messaging:channels:update",
    "messaging:channels:enable",
    "messaging:channels:disable",
    "messaging:channels:test",
    "messaging:dispatch:manage",
    "file:library:manage",
    "file:object:read",
    "file:object:upload",
    "file:object:delete",
    "basic-data:dictionary:read",
    "basic-data:dictionary:manage",
    "basic-data:region:read",
    "basic-data:region:manage",
    "basic-data:region:import",
    "cron:tasks:view",
    "cron:tasks:create",
    "cron:tasks:update",
    "cron:tasks:enable",
    "cron:tasks:disable",
    "cron:tasks:delete",
    "cron:tasks:trigger",
    "cron:runs:view",
]


def now_iso() -> str:
    return datetime.now().isoformat(timespec="microseconds")


def audit_insert_values(*, tenant_id: int = 1, actor: str | None = "system", actor_id: int | None = None) -> dict[str, Any]:
    timestamp = now_iso()
    return {
        "tenant_id": tenant_id,
        "lock_version": 0,
        "deleted": False,
        "create_time": timestamp,
        "creator": actor,
        "creator_id": actor_id,
        "update_time": timestamp,
        "editor": actor,
        "editor_id": actor_id,
    }


def audit_update_values(*, actor: str | None = "system", actor_id: int | None = None) -> dict[str, Any]:
    return {
        "update_time": now_iso(),
        "editor": actor,
        "editor_id": actor_id,
    }


def audit_insert_columns_sql() -> str:
    return "tenant_id, lock_version, deleted, create_time, creator, creator_id, update_time, editor, editor_id"


def audit_insert_placeholders_sql() -> str:
    return "?, ?, ?, ?, ?, ?, ?, ?, ?"


def audit_insert_params(*, tenant_id: int = 1, actor: str | None = "system", actor_id: int | None = None) -> tuple[Any, ...]:
    values = audit_insert_values(tenant_id=tenant_id, actor=actor, actor_id=actor_id)
    return (
        values["tenant_id"],
        values["lock_version"],
        values["deleted"],
        values["create_time"],
        values["creator"],
        values["creator_id"],
        values["update_time"],
        values["editor"],
        values["editor_id"],
    )


def audit_update_sql() -> str:
    return "update_time = ?, editor = ?, editor_id = ?, lock_version = lock_version + 1"


def audit_update_params(*, actor: str | None = "system", actor_id: int | None = None) -> tuple[Any, ...]:
    values = audit_update_values(actor=actor, actor_id=actor_id)
    return (values["update_time"], values["editor"], values["editor_id"])


def normalize_username(username: str) -> str:
    return username.strip()


def ensure_auth_schema(conn: Any) -> None:
    if backend_name(conn) == "sqlite":
        repair_sqlite_identity_tables_before_schema(conn)
    ensure_identity_schema(conn)
    ensure_menu_schema(conn)


def repair_sqlite_identity_tables_before_schema(conn: Any) -> None:
    migrate_sqlite_users_for_tenancy(conn)
    for table_name in (
        "tenants",
        "tenant_memberships",
        "users",
        "api_keys",
        "roles",
        "permissions",
        "menus",
        "user_roles",
        "role_permissions",
        "role_menus",
        "tenant_menu_overrides",
    ):
        columns = {str(row["name"]) for row in conn.execute(f"PRAGMA table_info({table_name})").fetchall()}
        if not columns:
            continue
        if "tenant_id" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN tenant_id INTEGER DEFAULT 1")
        if "lock_version" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN lock_version INTEGER NOT NULL DEFAULT 0")
        if "deleted" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0")
        if "create_time" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN create_time TEXT")
            conn.execute(f"UPDATE {table_name} SET create_time = ? WHERE create_time IS NULL", (now_iso(),))
        if "creator" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN creator TEXT DEFAULT NULL")
        if "creator_id" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN creator_id INTEGER DEFAULT NULL")
        if "update_time" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN update_time TEXT")
            conn.execute(f"UPDATE {table_name} SET update_time = ? WHERE update_time IS NULL", (now_iso(),))
        if "editor" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN editor TEXT DEFAULT NULL")
        if "editor_id" not in columns:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN editor_id INTEGER DEFAULT NULL")


def ensure_menu_schema(conn: Any) -> None:
    now = now_iso()
    if backend_name(conn) in {"postgres", "mysql"}:
        add_column_if_missing(conn, "users", "tenant_id", "BIGINT DEFAULT 1")
        add_column_if_missing(conn, "roles", "tenant_id", "BIGINT DEFAULT NULL")
        add_column_if_missing(conn, "roles", "role_scope", "TEXT DEFAULT 'platform'")
        add_column_if_missing(conn, "menus", "menu_type", "TEXT DEFAULT 'page'")
        add_column_if_missing(conn, "menus", "menu_scope", "TEXT DEFAULT 'tenant'")
        add_column_if_missing(conn, "menus", "component", "TEXT DEFAULT ''")
        add_column_if_missing(conn, "api_keys", "tenant_id", "BIGINT DEFAULT 1")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS tenant_menu_overrides (
                tenant_id BIGINT NOT NULL,
                menu_key TEXT NOT NULL,
                is_enabled BOOLEAN DEFAULT TRUE,
                create_time TEXT NOT NULL,
                update_time TEXT NOT NULL,
                PRIMARY KEY (tenant_id, menu_key)
            )
            """
        )
        conn.execute("UPDATE users SET tenant_id = 1 WHERE tenant_id IS NULL")
        conn.execute("UPDATE roles SET role_scope = 'platform' WHERE role_scope IS NULL OR role_scope = ''")
        conn.execute("UPDATE menus SET menu_scope = 'tenant' WHERE menu_scope IS NULL OR menu_scope = ''")
        if backend_name(conn) == "postgres":
            conn.execute(
                """
                DO $$
                DECLARE
                    constraint_name text;
                BEGIN
                    SELECT c.conname INTO constraint_name
                    FROM pg_constraint c
                    JOIN pg_class t ON t.oid = c.conrelid
                    JOIN pg_namespace n ON n.oid = t.relnamespace
                    WHERE t.relname = 'users'
                      AND c.contype = 'u'
                      AND (
                          SELECT array_agg(a.attname ORDER BY a.attnum)
                          FROM unnest(c.conkey) AS key(attnum)
                          JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = key.attnum
                      ) = ARRAY['username'];

                    IF constraint_name IS NOT NULL THEN
                        EXECUTE format('ALTER TABLE users DROP CONSTRAINT %I', constraint_name);
                    END IF;
                END $$;
                """
            )
        ensure_identity_indexes(conn)
        insert_seed_tenant_with_id(conn, 1, PLATFORM_TENANT_KEY, "Platform Administration", "System realm for platform administrators", now)
        insert_seed_tenant_with_id(conn, 2, DEFAULT_TENANT_KEY, "Default Tenant", "Migrated single-tenant workspace", now)
        return

    migrate_sqlite_users_for_tenancy(conn)
    role_columns = {
        str(row["name"])
        for row in conn.execute("PRAGMA table_info(roles)").fetchall()
    }
    if "tenant_id" not in role_columns:
        conn.execute("ALTER TABLE roles ADD COLUMN tenant_id INTEGER DEFAULT NULL")
    if "role_scope" not in role_columns:
        conn.execute("ALTER TABLE roles ADD COLUMN role_scope TEXT DEFAULT 'platform'")
    columns = {
        str(row["name"])
        for row in conn.execute("PRAGMA table_info(menus)").fetchall()
    }
    if "menu_type" not in columns:
        conn.execute("ALTER TABLE menus ADD COLUMN menu_type TEXT DEFAULT 'page'")
    if "menu_scope" not in columns:
        conn.execute("ALTER TABLE menus ADD COLUMN menu_scope TEXT DEFAULT 'tenant'")
    if "component" not in columns:
        conn.execute("ALTER TABLE menus ADD COLUMN component TEXT DEFAULT ''")
    api_key_columns = {
        str(row["name"])
        for row in conn.execute("PRAGMA table_info(api_keys)").fetchall()
    }
    if "tenant_id" not in api_key_columns:
        conn.execute("ALTER TABLE api_keys ADD COLUMN tenant_id INTEGER DEFAULT 1")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tenant_menu_overrides (
            tenant_id INTEGER NOT NULL,
            menu_key TEXT NOT NULL,
            is_enabled INTEGER DEFAULT 1,
            create_time TEXT NOT NULL,
            update_time TEXT NOT NULL,
            PRIMARY KEY (tenant_id, menu_key)
        )
        """
    )
    ensure_identity_indexes(conn)
    conn.execute("UPDATE roles SET role_scope = 'platform' WHERE role_scope IS NULL OR role_scope = ''")
    conn.execute("UPDATE menus SET menu_scope = 'tenant' WHERE menu_scope IS NULL OR menu_scope = ''")
    ensure_identity_indexes(conn)
    conn.execute(
        """
        INSERT INTO tenants (id, tenant_key, name, status, remark, create_time, update_time)
        SELECT 1, ?, ?, 'active', ?, ?, ?
        WHERE NOT EXISTS (SELECT 1 FROM tenants WHERE tenant_key = ?)
          AND NOT EXISTS (SELECT 1 FROM tenants WHERE id = 1)
        """,
        (
            PLATFORM_TENANT_KEY,
            "Platform Administration",
            "System realm for platform administrators",
            now,
            now,
            PLATFORM_TENANT_KEY,
        ),
    )
    conn.execute(
        """
        INSERT INTO tenants (id, tenant_key, name, status, remark, create_time, update_time)
        SELECT 2, ?, ?, 'active', ?, ?, ?
        WHERE NOT EXISTS (SELECT 1 FROM tenants WHERE tenant_key = ?)
          AND NOT EXISTS (SELECT 1 FROM tenants WHERE id = 2)
        """,
        (
            DEFAULT_TENANT_KEY,
            "Default Tenant",
            "Migrated single-tenant workspace",
            now,
            now,
            DEFAULT_TENANT_KEY,
        ),
    )


def migrate_sqlite_users_for_tenancy(conn: Any) -> None:
    user_columns = [dict(row) for row in conn.execute("PRAGMA table_info(users)").fetchall()]
    if not user_columns:
        return
    column_names = {str(row["name"]) for row in user_columns}
    required_columns = {
        "tenant_id",
        "lock_version",
        "deleted",
        "create_time",
        "creator",
        "creator_id",
        "update_time",
        "editor",
        "editor_id",
    }
    missing_required_columns = bool(required_columns - column_names)
    index_rows = [dict(row) for row in conn.execute("PRAGMA index_list(users)").fetchall()]
    has_global_username_unique = False
    for index_row in index_rows:
        if not bool(index_row.get("unique")):
            continue
        index_columns = [
            str(row["name"])
            for row in conn.execute(f"PRAGMA index_info({str(index_row['name'])})").fetchall()
        ]
        if index_columns == ["username"]:
            has_global_username_unique = True
            break
    if not missing_required_columns and not has_global_username_unique:
        return

    conn.execute("DROP TABLE IF EXISTS users_tenant_migration")
    conn.execute(
        """
        CREATE TABLE users_tenant_migration (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_id INTEGER DEFAULT 1,
            username TEXT NOT NULL,
            hashed_password TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            is_superuser INTEGER DEFAULT 0,
            lock_version INTEGER NOT NULL DEFAULT 0,
            deleted INTEGER NOT NULL DEFAULT 0,
            create_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            creator TEXT DEFAULT NULL,
            creator_id INTEGER DEFAULT NULL,
            update_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            editor TEXT DEFAULT NULL,
            editor_id INTEGER DEFAULT NULL,
            UNIQUE (tenant_id, username)
        )
        """
    )

    select_tenant = "tenant_id" if "tenant_id" in column_names else "1 AS tenant_id"
    select_lock_version = "lock_version" if "lock_version" in column_names else "0 AS lock_version"
    select_deleted = "deleted" if "deleted" in column_names else "0 AS deleted"
    select_creator = "creator" if "creator" in column_names else "NULL AS creator"
    select_creator_id = "creator_id" if "creator_id" in column_names else "NULL AS creator_id"
    select_editor = "editor" if "editor" in column_names else "NULL AS editor"
    select_editor_id = "editor_id" if "editor_id" in column_names else "NULL AS editor_id"
    conn.execute(
        f"""
        INSERT INTO users_tenant_migration (
            id, tenant_id, username, hashed_password, is_active, is_superuser,
            lock_version, deleted, create_time, creator, creator_id, update_time, editor, editor_id
        )
        SELECT id, {select_tenant}, username, hashed_password, is_active, is_superuser,
            {select_lock_version}, {select_deleted}, create_time, {select_creator}, {select_creator_id},
            update_time, {select_editor}, {select_editor_id}
        FROM users
        """
    )
    conn.execute("DROP TABLE users")
    conn.execute("ALTER TABLE users_tenant_migration RENAME TO users")


def ensure_identity_indexes(conn: Any) -> None:
    index_statements = (
        ("idx_api_keys_tenant", "CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys(tenant_id)"),
        (
            "idx_users_tenant_username_unique",
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_users_tenant_username_unique ON users(tenant_id, username)",
        ),
        ("idx_users_tenant_username", "CREATE INDEX IF NOT EXISTS idx_users_tenant_username ON users(tenant_id, username)"),
        ("idx_roles_scope", "CREATE INDEX IF NOT EXISTS idx_roles_scope ON roles(role_scope)"),
        ("idx_menus_scope", "CREATE INDEX IF NOT EXISTS idx_menus_scope ON menus(menu_scope)"),
        (
            "idx_tenant_menu_overrides_tenant",
            "CREATE INDEX IF NOT EXISTS idx_tenant_menu_overrides_tenant ON tenant_menu_overrides(tenant_id)",
        ),
    )
    for index_name, statement in index_statements:
        if backend_name(conn) == "mysql":
            statement = statement.replace(" IF NOT EXISTS", "")
            if index_exists(conn, index_name):
                continue
        conn.execute(statement)


def insert_seed_tenant_with_id(conn: Any, tenant_id: int, tenant_key: str, name: str, remark: str, now: str) -> None:
    if backend_name(conn) == "mysql":
        conn.execute(
            """
            INSERT INTO tenants (id, tenant_key, name, status, remark, create_time, update_time)
            SELECT ?, ?, ?, 'active', ?, ?, ?
            WHERE NOT EXISTS (SELECT 1 FROM tenants WHERE tenant_key = ?)
              AND NOT EXISTS (SELECT 1 FROM tenants WHERE id = ?)
            """,
            (tenant_id, tenant_key, name, remark, now, now, tenant_key, tenant_id),
        )
        return
    override = "OVERRIDING SYSTEM VALUE" if backend_name(conn) == "postgres" else ""
    conn.execute(
        f"""
        INSERT INTO tenants (id, tenant_key, name, status, remark, create_time, update_time)
        {override}
        SELECT ?, ?, ?, 'active', ?, ?, ?
        WHERE NOT EXISTS (SELECT 1 FROM tenants WHERE tenant_key = ?)
          AND NOT EXISTS (SELECT 1 FROM tenants WHERE id = ?)
        """,
        (tenant_id, tenant_key, name, remark, now, now, tenant_key, tenant_id),
    )


def ensure_platform_tenant(conn: Any) -> dict[str, Any]:
    now = now_iso()
    row = conn.execute("SELECT * FROM tenants WHERE tenant_key = ?", (PLATFORM_TENANT_KEY,)).fetchone()
    if not row:
        conn.execute(
            """
            INSERT INTO tenants (tenant_key, name, status, remark, create_time, update_time)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                PLATFORM_TENANT_KEY,
                "Platform Administration",
                "active",
                "System realm for platform administrators",
                now,
                now,
            ),
        )
        row = conn.execute("SELECT * FROM tenants WHERE tenant_key = ?", (PLATFORM_TENANT_KEY,)).fetchone()
    return dict(row)


def ensure_default_tenant(conn: Any) -> dict[str, Any]:
    now = now_iso()
    row = conn.execute("SELECT * FROM tenants WHERE tenant_key = ?", (DEFAULT_TENANT_KEY,)).fetchone()
    if not row:
        conn.execute(
            """
            INSERT INTO tenants (tenant_key, name, status, remark, create_time, update_time)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (DEFAULT_TENANT_KEY, "Default Tenant", "active", "Migrated single-tenant workspace", now, now),
        )
        row = conn.execute("SELECT * FROM tenants WHERE tenant_key = ?", (DEFAULT_TENANT_KEY,)).fetchone()
    return dict(row)


def ensure_default_admin(conn: Any) -> None:
    tenant = ensure_platform_tenant(conn)
    tenant_id = int(tenant["id"])
    username = default_admin_username()
    row = conn.execute(
        "SELECT id FROM users WHERE tenant_id = ? AND username = ?",
        (tenant_id, username),
    ).fetchone()
    now = now_iso()
    if row:
        conn.execute(
            """
            UPDATE users
            SET is_active = TRUE,
                is_superuser = TRUE,
                update_time = ?
            WHERE id = ?
            """,
            (now, int(row["id"])),
        )
        return

    legacy = conn.execute(
        """
        SELECT id
        FROM users
        WHERE username = ? AND is_superuser = TRUE
        ORDER BY id
        LIMIT 1
        """,
        (username,),
    ).fetchone()
    if legacy:
        conn.execute(
            """
            UPDATE users
            SET tenant_id = ?,
                is_active = TRUE,
                is_superuser = TRUE,
                update_time = ?
            WHERE id = ?
            """,
            (tenant_id, now, int(legacy["id"])),
        )
        conn.execute("DELETE FROM tenant_memberships WHERE user_id = ?", (int(legacy["id"]),))
        return

    conn.execute(
        """
        INSERT INTO users (tenant_id, username, hashed_password, is_active, is_superuser, create_time, update_time)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            tenant_id,
            username,
            hash_password(default_admin_password()),
            True,
            True,
            now,
            now,
        ),
    )


def ensure_tenant_menu_defaults(conn: Any, tenant_id: int) -> None:
    tenant = conn.execute("SELECT tenant_key FROM tenants WHERE id = ?", (tenant_id,)).fetchone()
    if not tenant or str(tenant["tenant_key"]) == PLATFORM_TENANT_KEY:
        return
    now = now_iso()
    for menu_key in DEFAULT_TENANT_ENABLED_MENU_KEYS:
        conn.execute(
            """
            INSERT INTO tenant_menu_overrides (tenant_id, menu_key, is_enabled, create_time, update_time)
            SELECT ?, ?, TRUE, ?, ?
            WHERE NOT EXISTS (
                SELECT 1 FROM tenant_menu_overrides WHERE tenant_id = ? AND menu_key = ?
            )
            """,
            (tenant_id, menu_key, now, now, tenant_id, menu_key),
        )


def ensure_all_tenant_menu_defaults(conn: Any) -> None:
    rows = conn.execute("SELECT id FROM tenants WHERE tenant_key <> ?", (PLATFORM_TENANT_KEY,)).fetchall()
    for row in rows:
        ensure_tenant_menu_defaults(conn, int(row["id"]))


def ensure_default_admin_membership(conn: Any) -> None:
    tenant = ensure_default_tenant(conn)
    platform_tenant = ensure_platform_tenant(conn)
    conn.execute("UPDATE api_keys SET tenant_id = ? WHERE tenant_id IS NULL", (int(tenant["id"]),))
    conn.execute(
        "UPDATE api_keys SET tenant_id = ? WHERE tenant_id = ?",
        (int(tenant["id"]), int(platform_tenant["id"])),
    )


def ensure_default_rbac(conn: Any) -> None:
    admin_role = conn.execute("SELECT id FROM roles WHERE role_key = ?", (DEFAULT_ROLE_KEY,)).fetchone()
    ensure_identity_seed(conn)
    ensure_file_management_permissions(conn)
    retire_tenant_menu_keys(conn, RETIRED_AI_ASSETS_MENU_KEYS)
    retire_permission_codes(conn, RETIRED_AI_ASSETS_PERMISSION_CODES)
    ensure_platform_default_menus(conn)
    backfill_default_menu_metadata(conn)
    admin_role = conn.execute("SELECT id FROM roles WHERE role_key = ?", (DEFAULT_ROLE_KEY,)).fetchone()
    if not admin_role:
        return
    role_id = int(admin_role["id"])
    conn.execute(
        """
        INSERT INTO user_roles (user_id, role_id)
        SELECT id, ? FROM users
        WHERE is_superuser = ? AND NOT EXISTS (
            SELECT 1 FROM user_roles WHERE user_id = users.id AND role_id = ?
        )
        """,
        (role_id, True, role_id),
    )
    ensure_default_admin_membership(conn)
    ensure_tenant_default_menus(conn)
    ensure_tenant_default_roles(conn)
    ensure_role_menus_by_key(conn, DEFAULT_ROLE_KEY, ["platform-management", "platform-branding", "platform-branding-update"])
    repair_tenant_rbac_boundaries(conn)
    ensure_all_tenant_menu_defaults(conn)


def ensure_file_management_permissions(conn: Any) -> None:
    permission_rows = [
        ("file:library:manage", "管理文件库", "创建、更新和删除租户文件库"),
        ("file:object:read", "查看文件", "浏览、搜索和下载租户文件"),
        ("file:object:upload", "上传文件", "上传文件到租户文件库"),
        ("file:object:delete", "删除文件", "删除租户文件"),
        ("file:quota:manage", "管理文件配额", "配置租户文件存储配额"),
        (
            "file:storage_profiles:manage",
            "管理存储配置",
            "配置文件管理使用的对象存储方案",
        ),
        (
            "file:preview_profiles:manage",
            "管理预览配置",
            "配置文件预览使用的外部服务",
        ),
        (
            "basic-data:dictionary:read",
            "查看业务字典",
            "查看和使用租户业务字典",
        ),
        (
            "basic-data:dictionary:manage",
            "管理业务字典",
            "创建、更新、停用和删除租户业务字典",
        ),
        (
            "basic-data:region:read",
            "查看区域",
            "查看和使用租户区域数据",
        ),
        (
            "basic-data:region:manage",
            "管理区域",
            "创建、更新、停用和删除租户区域",
        ),
        (
            "basic-data:region:import",
            "导入区域",
            "导入租户区域数据",
        ),
        (
            "organization:departments:read",
            "查看组织部门",
            "查看租户组织部门",
        ),
        (
            "organization:departments:manage",
            "管理组织部门",
            "维护租户组织部门和用户部门关系",
        ),
        (
            "authorization:data-resource:manage",
            "管理数据资源定义",
            "维护平台级数据权限资源定义",
        ),
        (
            "authorization:data-scope:read",
            "查看数据权限",
            "查看数据权限资源和角色策略",
        ),
        (
            "authorization:data-scope:manage",
            "管理数据权限",
            "配置角色数据权限策略",
        ),
        (
            "prompt:assets:view",
            "查看提示词资产",
            "查看提示词资产和版本",
        ),
        (
            "prompt:assets:manage",
            "管理提示词资产",
            "创建、更新、发布和归档提示词资产",
        ),
    ]
    permission_rows.extend(
        [
            ("ai_studio:access", "AI Studio access", "Access tenant AI Studio"),
            ("ai_applications:read", "AI application read", "View tenant AI applications"),
            ("ai_applications:manage", "AI application manage", "Create and update tenant AI applications"),
            ("ai_applications:publish", "AI application publish", "Publish tenant AI application APIs"),
            ("ai_applications:run", "AI application run", "Run or debug tenant AI applications"),
            ("ai_capabilities:read", "AI capability read", "View tenant AI capabilities"),
            ("ai_capabilities:manage", "AI capability manage", "Create and update tenant AI capabilities"),
            ("ai_capabilities:execute", "AI capability execute", "Execute tenant AI capabilities"),
            ("ai_runtime:trace:read", "AI runtime trace read", "View AI runtime traces"),
            ("ai_studio:quota:read", "AI Studio quota read", "View tenant AI Studio quotas"),
            ("ai_studio:quota:manage", "AI Studio quota manage", "Manage tenant AI Studio quotas"),
        ]
    )
    for code, name, description in permission_rows:
        conn.execute(
            """
            INSERT INTO permissions (code, name, description)
            SELECT ?, ?, ?
            WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE code = ?)
            """,
            (code, name, description, code),
        )
        conn.execute(
            """
            UPDATE permissions
            SET name = ?, description = ?
            WHERE code = ?
            """,
            (name, description, code),
        )


def backfill_default_menu_metadata(conn: Any) -> None:
    retire_platform_menu_keys(conn, ["settings", "api-keys"])
    default_tenant_scoped_platform_keys = {
        "rbac",
        "menu-management",
        "role-management",
        "user-management",
        "platform-management",
        "platform-branding",
        "tenant-management",
        "appearance-studio",
    }
    for menu_key, metadata in DEFAULT_MENU_METADATA.items():
        existing = conn.execute("SELECT id, menu_scope FROM menus WHERE menu_key = ?", (menu_key,)).fetchone()
        should_set_scope = existing is None or (
            metadata["menu_scope"] != str(existing["menu_scope"] or "")
        ) or (
            metadata["menu_scope"] == "platform"
            and menu_key in default_tenant_scoped_platform_keys
            and str(existing["menu_scope"] or "") == "tenant"
        )
        child_exists = bool(conn.execute("SELECT 1 FROM menus WHERE parent_key = ? LIMIT 1", (menu_key,)).fetchone())
        next_menu_type = metadata["menu_type"] if not child_exists or metadata["menu_type"] != "directory" else "directory"
        conn.execute(
            """
            UPDATE menus
            SET menu_type = CASE
                    WHEN menu_type IS NULL OR menu_type = '' THEN ?
                    WHEN ? = 'directory' AND menu_type = 'page' AND ? THEN 'directory'
                    ELSE menu_type
                END,
                component = CASE WHEN component IS NULL OR component = '' THEN ? ELSE component END,
                menu_scope = CASE WHEN ? THEN ? ELSE menu_scope END
            WHERE menu_key = ?
            """,
            (
                metadata["menu_type"],
                next_menu_type,
                child_exists,
                metadata["component"],
                should_set_scope,
                metadata["menu_scope"],
                menu_key,
            ),
        )
    conn.execute("UPDATE menus SET menu_scope = 'tenant' WHERE menu_key IN ('llm', 'llm-config', 'llm-debug')")
    conn.execute("UPDATE menus SET parent_key = '' WHERE menu_key = 'llm' AND menu_scope = 'tenant' AND parent_key IS NULL")
    conn.execute("UPDATE menus SET parent_key = 'llm' WHERE menu_key IN ('llm-config', 'llm-debug') AND (parent_key IS NULL OR parent_key = '')")
    label_rows = [
        ("llm", "大模型"),
        ("llm-config", "模型配置"),
        ("llm-debug", "模型调试"),
        ("tenant-settings", "租户设置"),
        ("tenant-user-management", "成员管理"),
        ("tenant-api-keys", "API 密钥"),
        ("tenant-management", "租户管理"),
        ("appearance-studio", "主题管理"),
        ("rbac", "权限管理"),
        ("user-management", "用户管理"),
        ("menu-management", "菜单权限"),
        ("role-management", "角色权限"),
    ]
    for menu_key, label in label_rows:
        conn.execute("UPDATE menus SET label = ? WHERE menu_key = ? AND (label IS NULL OR label = '')", (label, menu_key))
    basic_data_label_rows = [
        ("basic-data", "基础数据"),
        ("basic-data-dictionaries", "业务字典"),
    ]
    for menu_key, label in basic_data_label_rows:
        conn.execute("UPDATE menus SET label = ? WHERE menu_key = ?", (label, menu_key))
    conn.execute(
        """
        UPDATE menus
        SET label = '数据权限',
            menu_type = 'page',
            path = '/authorization/data-scope',
            route_name = 'data-scope-management',
            component = '/authorization/data-scope/index',
            icon = 'SafetyCertificateOutlined',
            parent_key = 'organization',
            permission_code = 'authorization:data-scope:read',
            sort_order = 832,
            is_visible = TRUE,
            menu_scope = 'tenant'
        WHERE menu_key = 'data-scope-management'
        """
    )
    conn.execute(
        """
        UPDATE menus
        SET label = CASE
                WHEN menu_key = 'data-scope-management-read' THEN '查看数据权限'
                ELSE '管理数据权限'
            END,
            menu_type = 'action',
            path = '',
            route_name = '',
            component = '',
            icon = '',
            parent_key = 'data-scope-management',
            permission_code = CASE
                WHEN menu_key = 'data-scope-management-read' THEN 'authorization:data-scope:read'
                ELSE 'authorization:data-scope:manage'
            END,
            sort_order = CASE
                WHEN menu_key = 'data-scope-management-read' THEN 8321
                ELSE 8322
            END,
            is_visible = TRUE,
            menu_scope = 'tenant'
        WHERE menu_key IN ('data-scope-management-read', 'data-scope-management-manage')
        """
    )
    conn.execute(
        """
        UPDATE menus
        SET label = '平台管理',
            menu_type = 'directory',
            path = '/platform',
            route_name = 'platform-management',
            component = '',
            icon = 'SettingOutlined',
            parent_key = '',
            permission_code = '',
            sort_order = 109,
            is_visible = TRUE,
            menu_scope = 'platform'
        WHERE menu_key = 'platform-management'
        """
    )


def retire_platform_menu_keys(conn: Any, menu_keys: list[str]) -> None:
    placeholders = ", ".join("?" for _ in menu_keys)
    conn.execute(
        f"""
        DELETE FROM role_menus
        WHERE menu_id IN (
            SELECT id FROM menus
            WHERE menu_scope = 'platform'
              AND menu_key IN ({placeholders})
        )
        """,
        tuple(menu_keys),
    )
    conn.execute(
        f"""
        DELETE FROM menus
        WHERE menu_scope = 'platform'
          AND menu_key IN ({placeholders})
        """,
        tuple(menu_keys),
    )


def retire_tenant_menu_keys(conn: Any, menu_keys: list[str]) -> None:
    if not menu_keys:
        return
    placeholders = ", ".join("?" for _ in menu_keys)
    conn.execute(
        f"""
        DELETE FROM role_menus
        WHERE menu_id IN (
            SELECT id FROM menus
            WHERE menu_scope = 'tenant'
              AND menu_key IN ({placeholders})
        )
        """,
        tuple(menu_keys),
    )
    conn.execute(
        f"""
        DELETE FROM tenant_menu_overrides
        WHERE menu_key IN ({placeholders})
        """,
        tuple(menu_keys),
    )
    conn.execute(
        f"""
        DELETE FROM menus
        WHERE menu_scope = 'tenant'
          AND menu_key IN ({placeholders})
        """,
        tuple(menu_keys),
    )


def retire_permission_codes(conn: Any, permission_codes: list[str]) -> None:
    if not permission_codes:
        return
    placeholders = ", ".join("?" for _ in permission_codes)
    conn.execute(
        f"""
        DELETE FROM role_permissions
        WHERE permission_id IN (
            SELECT id FROM permissions
            WHERE code IN ({placeholders})
        )
        """,
        tuple(permission_codes),
    )
    conn.execute(
        f"""
        DELETE FROM permissions
        WHERE code IN ({placeholders})
        """,
        tuple(permission_codes),
    )


def ensure_platform_default_menus(conn: Any) -> None:
    platform_menu_rows = [
        ("platform-management", "平台管理", "/platform", "platform-management", "SettingOutlined", "", "", 109),
        ("platform-branding", "平台信息", "/platform/branding", "platform-branding", "SettingOutlined", "platform-management", "", 1091),
        ("platform-branding-update", "更新平台标识", "", "", "", "platform-branding", "platform:branding:update", 10911),
        ("file-storage-profiles", "文件存储", "/files/storage-profiles", "file-storage-profiles", "database", "platform-management", "file:storage_profiles:manage", 1092),
        ("file-storage-profiles-manage", "管理文件存储", "", "", "", "file-storage-profiles", "file:storage_profiles:manage", 10921),
        ("file-preview-profiles", "文件预览", "/files/preview-profiles", "file-preview-profiles", "eye", "platform-management", "file:preview_profiles:manage", 1093),
        ("file-preview-profiles-manage", "管理文件预览", "", "", "", "file-preview-profiles", "file:preview_profiles:manage", 10931),
        ("file-tenant-quotas", "文件配额", "/files/tenant-quotas", "file-tenant-quotas", "hdd", "platform-management", "file:quota:manage", 1094),
        ("file-tenant-quotas-manage", "管理文件配额", "", "", "", "file-tenant-quotas", "file:quota:manage", 10941),
        ("ai-tenant-quotas", "AI application quotas", "/ai/tenant-quotas", "ai-tenant-quotas", "robot", "platform-management", "ai_studio:quota:manage", 1095),
        ("ai-tenant-quotas-manage", "Manage AI application quotas", "", "", "", "ai-tenant-quotas", "ai_studio:quota:manage", 10951),
        ("rbac", "权限管理", "", "", "shield", "", "", 100),
        ("user-management", "用户管理", "/rbac/users", "user-management", "user", "rbac", "system:user:access", 100),
        ("user-management-create", "新增用户", "", "", "", "user-management", "system:users:create", 1001),
        ("user-management-update", "编辑用户", "", "", "", "user-management", "system:users:update", 1002),
        ("user-management-enable", "启用用户", "", "", "", "user-management", "system:users:enable", 1003),
        ("user-management-disable", "停用用户", "", "", "", "user-management", "system:users:disable", 1004),
        ("menu-management", "菜单权限", "/rbac/menus", "menu-management", "menu", "rbac", "system:menu:access", 101),
        ("menu-management-create", "新增菜单", "", "", "", "menu-management", "system:menus:create", 1011),
        ("menu-management-update", "编辑菜单", "", "", "", "menu-management", "system:menus:update", 1012),
        ("menu-management-delete", "删除菜单", "", "", "", "menu-management", "system:menus:delete", 1013),
        ("role-management", "角色权限", "/rbac/roles", "role-management", "users", "rbac", "system:role:access", 102),
        ("role-management-create", "新增角色", "", "", "", "role-management", "system:roles:create", 1021),
        ("role-management-update", "编辑角色", "", "", "", "role-management", "system:roles:update", 1022),
        ("role-management-delete", "删除角色", "", "", "", "role-management", "system:roles:delete", 1023),
        ("role-management-assign-menus", "分配菜单权限", "", "", "", "role-management", "system:roles:assign_menus", 1024),
        ("tenant-management", "租户管理", "/tenant", "tenant-management", "ApartmentOutlined", "", "tenant:access", 110),
        ("tenant-management-create", "新增租户", "", "", "", "tenant-management", "tenant:create", 1101),
        ("tenant-management-update", "编辑租户", "", "", "", "tenant-management", "tenant:update", 1102),
        ("tenant-management-activate", "启用租户", "", "", "", "tenant-management", "tenant:activate", 1103),
        ("tenant-management-suspend", "停用租户", "", "", "", "tenant-management", "tenant:suspend", 1104),
        ("tenant-management-users-create", "新增租户成员", "", "", "", "tenant-management", "tenant:users:create", 1105),
        ("tenant-management-users-update", "编辑租户成员", "", "", "", "tenant-management", "tenant:users:update", 1106),
        ("tenant-management-api-keys-create", "新增租户 API Key", "", "", "", "tenant-management", "tenant:api_keys:create", 1107),
        ("tenant-management-api-keys-revoke", "撤销租户 API Key", "", "", "", "tenant-management", "tenant:api_keys:revoke", 1108),
        ("tenant-management-theme-assign", "分配租户主题", "", "", "", "tenant-management", "tenant:theme:assign", 1109),
        ("appearance-studio", "主题管理", "/settings/appearance-studio", "appearance-studio", "BgColorsOutlined", "", "appearance:access", 120),
        ("appearance-themes-create", "新建主题", "", "", "", "appearance-studio", "appearance:themes:create", 1201),
        ("appearance-themes-update", "编辑主题", "", "", "", "appearance-studio", "appearance:themes:update", 1202),
        ("appearance-themes-publish", "发布主题", "", "", "", "appearance-studio", "appearance:themes:publish", 1203),
        ("appearance-themes-disable", "停用主题", "", "", "", "appearance-studio", "appearance:themes:disable", 1204),
        ("appearance-themes-set-default", "设为平台默认", "", "", "", "appearance-studio", "appearance:themes:set_default", 1205),
    ]
    for key, label, path, route_name, icon, parent_key, permission_code, sort_order in platform_menu_rows:
        conn.execute(
            """
            INSERT INTO menus (
                menu_key, menu_scope, label, menu_type, path, route_name, component, icon,
                parent_key, permission_code, sort_order, is_visible
            )
            SELECT ?, 'platform', ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE
            WHERE NOT EXISTS (SELECT 1 FROM menus WHERE menu_key = ?)
            """,
            (
                key,
                label,
                DEFAULT_MENU_METADATA[key]["menu_type"],
                path,
                route_name,
                DEFAULT_MENU_METADATA[key]["component"],
                icon,
                parent_key,
                permission_code,
                sort_order,
                key,
            ),
        )
    backfill_default_menu_metadata(conn)


def ensure_tenant_default_menus(conn: Any) -> None:
    tenant_menu_rows = [
        (
            "tenant-settings",
            "租户设置",
            "",
            "",
            "setting",
            "",
            "",
            80,
        ),
        (
            "tenant-user-management",
            "成员管理",
            "/tenant",
            "tenant-user-management",
            "user",
            "tenant-settings",
            "tenant:user:manage",
            81,
        ),
        (
            "tenant-users-create",
            "新增成员",
            "",
            "",
            "",
            "tenant-user-management",
            "tenant:users:create",
            811,
        ),
        (
            "tenant-users-update",
            "编辑成员",
            "",
            "",
            "",
            "tenant-user-management",
            "tenant:users:update",
            812,
        ),
        (
            "tenant-users-enable",
            "启用成员",
            "",
            "",
            "",
            "tenant-user-management",
            "tenant:users:enable",
            813,
        ),
        (
            "tenant-users-disable",
            "停用成员",
            "",
            "",
            "",
            "tenant-user-management",
            "tenant:users:disable",
            814,
        ),
        (
            "tenant-api-keys",
            "API 密钥",
            "/settings/api-keys",
            "tenant-api-keys",
            "key",
            "tenant-settings",
            "tenant:api_key:manage",
            82,
        ),
        (
            "tenant-api-keys-create",
            "新增 API Key",
            "",
            "",
            "",
            "tenant-api-keys",
            "tenant:api_keys:create",
            821,
        ),
        (
            "tenant-api-keys-revoke",
            "撤销 API Key",
            "",
            "",
            "",
            "tenant-api-keys",
            "tenant:api_keys:revoke",
            822,
        ),
        (
            "organization",
            "组织管理",
            "",
            "",
            "ApartmentOutlined",
            "",
            "",
            83,
        ),
        (
            "organization-departments",
            "部门管理",
            "/organization/departments",
            "organization-departments",
            "PartitionOutlined",
            "organization",
            "organization:departments:read",
            831,
        ),
        (
            "organization-departments-create",
            "新增部门",
            "",
            "",
            "",
            "organization-departments",
            "organization:departments:manage",
            8311,
        ),
        (
            "organization-departments-update",
            "编辑部门",
            "",
            "",
            "",
            "organization-departments",
            "organization:departments:manage",
            8312,
        ),
        (
            "organization-departments-delete",
            "删除部门",
            "",
            "",
            "",
            "organization-departments",
            "organization:departments:manage",
            8313,
        ),
        (
            "data-scope-management",
            "数据权限",
            "/authorization/data-scope",
            "data-scope-management",
            "SafetyCertificateOutlined",
            "organization",
            "authorization:data-scope:read",
            832,
        ),
        (
            "data-scope-management-read",
            "查看数据权限",
            "",
            "",
            "",
            "data-scope-management",
            "authorization:data-scope:read",
            8321,
        ),
        (
            "data-scope-management-manage",
            "管理数据权限",
            "",
            "",
            "",
            "data-scope-management",
            "authorization:data-scope:manage",
            8322,
        ),
        (
            "file-management",
            "文件管理",
            "",
            "",
            "folder",
            "",
            "",
            83,
        ),
        (
            "file-libraries",
            "文件库",
            "/files/libraries",
            "file-libraries",
            "folder-open",
            "file-management",
            "file:object:read",
            831,
        ),
        (
            "file-libraries-create",
            "新建文件库",
            "",
            "",
            "",
            "file-libraries",
            "file:library:manage",
            8311,
        ),
        (
            "file-libraries-update",
            "编辑文件库",
            "",
            "",
            "",
            "file-libraries",
            "file:library:manage",
            8312,
        ),
        (
            "file-libraries-delete",
            "删除文件库",
            "",
            "",
            "",
            "file-libraries",
            "file:library:manage",
            8313,
        ),
        (
            "file-objects",
            "文件",
            "/files/objects",
            "file-objects",
            "file",
            "file-management",
            "file:object:read",
            832,
        ),
        (
            "file-objects-upload",
            "上传文件",
            "",
            "",
            "",
            "file-objects",
            "file:object:upload",
            8321,
        ),
        (
            "file-objects-delete",
            "删除文件",
            "",
            "",
            "",
            "file-objects",
            "file:object:delete",
            8322,
        ),
        (
            "basic-data",
            "基础数据",
            "",
            "",
            "database",
            "",
            "",
            84,
        ),
        (
            "basic-data-dictionaries",
            "业务字典",
            "/basic-data/dictionaries",
            "basic-data-dictionaries",
            "database",
            "basic-data",
            "basic-data:dictionary:read",
            841,
        ),
        (
            "basic-data-dictionaries-create",
            "新建业务字典",
            "",
            "",
            "",
            "basic-data-dictionaries",
            "basic-data:dictionary:manage",
            8411,
        ),
        (
            "basic-data-dictionaries-update",
            "编辑业务字典",
            "",
            "",
            "",
            "basic-data-dictionaries",
            "basic-data:dictionary:manage",
            8412,
        ),
        (
            "basic-data-dictionaries-delete",
            "删除业务字典",
            "",
            "",
            "",
            "basic-data-dictionaries",
            "basic-data:dictionary:manage",
            8413,
        ),
        (
            "basic-data-items-create",
            "新建字典项",
            "",
            "",
            "",
            "basic-data-dictionaries",
            "basic-data:dictionary:manage",
            8414,
        ),
        (
            "basic-data-items-update",
            "编辑字典项",
            "",
            "",
            "",
            "basic-data-dictionaries",
            "basic-data:dictionary:manage",
            8415,
        ),
        (
            "basic-data-items-delete",
            "删除字典项",
            "",
            "",
            "",
            "basic-data-dictionaries",
            "basic-data:dictionary:manage",
            8416,
        ),
        (
            "basic-data-regions",
            "区域管理",
            "/basic-data/regions",
            "basic-data-regions",
            "environment",
            "basic-data",
            "basic-data:region:read",
            842,
        ),
        (
            "basic-data-regions-create",
            "新建区域",
            "",
            "",
            "",
            "basic-data-regions",
            "basic-data:region:manage",
            8421,
        ),
        (
            "basic-data-regions-update",
            "编辑区域",
            "",
            "",
            "",
            "basic-data-regions",
            "basic-data:region:manage",
            8422,
        ),
        (
            "basic-data-regions-delete",
            "删除区域",
            "",
            "",
            "",
            "basic-data-regions",
            "basic-data:region:manage",
            8423,
        ),
        (
            "basic-data-regions-import",
            "导入区域",
            "",
            "",
            "",
            "basic-data-regions",
            "basic-data:region:import",
            8424,
        ),
        (
            "llm",
            "大模型",
            "",
            "",
            "experiment",
            "",
            "",
            90,
        ),
        (
            "messaging",
            "消息系统",
            "",
            "",
            "message",
            "",
            "",
            85,
        ),
        (
            "message-inbox",
            "站内信",
            "/messaging/inbox",
            "message-inbox",
            "inbox",
            "messaging",
            "messaging:inbox:view",
            86,
        ),
        (
            "message-inbox-read",
            "标记已读",
            "",
            "",
            "",
            "message-inbox",
            "messaging:inbox:manage_self",
            861,
        ),
        (
            "message-inbox-unread",
            "标记未读",
            "",
            "",
            "",
            "message-inbox",
            "messaging:inbox:manage_self",
            862,
        ),
        (
            "message-inbox-delete",
            "删除站内信",
            "",
            "",
            "",
            "message-inbox",
            "messaging:inbox:manage_self",
            863,
        ),
        (
            "message-outbox",
            "发送记录",
            "/messaging/outbox",
            "message-outbox",
            "send",
            "messaging",
            "messaging:messages:view",
            87,
        ),
        (
            "message-outbox-cancel",
            "取消发送",
            "",
            "",
            "",
            "message-outbox",
            "messaging:messages:cancel",
            871,
        ),
        (
            "message-send",
            "发送消息",
            "/messaging/send",
            "message-send",
            "edit",
            "messaging",
            "messaging:messages:send",
            88,
        ),
        (
            "message-send-submit",
            "发送消息",
            "",
            "",
            "",
            "message-send",
            "messaging:messages:send",
            881,
        ),
        (
            "message-templates",
            "消息模板",
            "/messaging/templates",
            "message-templates",
            "file-text",
            "messaging",
            "messaging:templates:view",
            89,
        ),
        (
            "message-templates-create",
            "新增模板",
            "",
            "",
            "",
            "message-templates",
            "messaging:templates:create",
            891,
        ),
        (
            "message-templates-update",
            "编辑模板",
            "",
            "",
            "",
            "message-templates",
            "messaging:templates:update",
            892,
        ),
        (
            "message-templates-enable",
            "启用模板",
            "",
            "",
            "",
            "message-templates",
            "messaging:templates:enable",
            893,
        ),
        (
            "message-templates-disable",
            "停用模板",
            "",
            "",
            "",
            "message-templates",
            "messaging:templates:disable",
            894,
        ),
        (
            "message-channels",
            "渠道配置",
            "/messaging/channels",
            "message-channels",
            "api",
            "messaging",
            "messaging:channels:view",
            90,
        ),
        (
            "message-channels-create",
            "新增渠道",
            "",
            "",
            "",
            "message-channels",
            "messaging:channels:create",
            901,
        ),
        (
            "message-channels-update",
            "编辑渠道",
            "",
            "",
            "",
            "message-channels",
            "messaging:channels:update",
            902,
        ),
        (
            "message-channels-enable",
            "启用渠道",
            "",
            "",
            "",
            "message-channels",
            "messaging:channels:enable",
            903,
        ),
        (
            "message-channels-disable",
            "停用渠道",
            "",
            "",
            "",
            "message-channels",
            "messaging:channels:disable",
            904,
        ),
        (
            "message-channels-test",
            "测试渠道",
            "",
            "",
            "",
            "message-channels",
            "messaging:channels:test",
            905,
        ),
        (
            "llm-config",
            "模型配置",
            "/settings/llm-config",
            "llm-config",
            "settings",
            "llm",
            "llm_config:access",
            91,
        ),
        (
            "llm-providers-save",
            "保存供应商",
            "",
            "",
            "",
            "llm-config",
            "llm:providers:save",
            911,
        ),
        (
            "llm-models-save",
            "保存模型",
            "",
            "",
            "",
            "llm-config",
            "llm:models:save",
            912,
        ),
        (
            "llm-tasks-register",
            "注册任务",
            "",
            "",
            "",
            "llm-config",
            "llm:tasks:register",
            913,
        ),
        (
            "llm-routing-policies-save",
            "保存路由策略",
            "",
            "",
            "",
            "llm-config",
            "llm:routing_policies:save",
            914,
        ),
        (
            "llm-debug",
            "模型调试",
            "/settings/llm-debug",
            "llm-debug",
            "experiment",
            "llm",
            "llm_debug:access",
            92,
        ),
        (
            "llm-debug-send",
            "发送调试请求",
            "",
            "",
            "",
            "llm-debug",
            "llm_debug:send",
            921,
        ),
        (
            "ai-studio",
            "AI Studio",
            "/ai/studio",
            "ai-studio",
            "robot",
            "",
            "ai_studio:access",
            93,
        ),
        (
            "ai-studio-app-manage",
            "Manage AI applications",
            "",
            "",
            "",
            "ai-studio",
            "ai_applications:manage",
            931,
        ),
        (
            "ai-studio-app-read",
            "View AI applications",
            "",
            "",
            "",
            "ai-studio",
            "ai_applications:read",
            930,
        ),
        (
            "ai-studio-app-publish",
            "Publish AI applications",
            "",
            "",
            "",
            "ai-studio",
            "ai_applications:publish",
            932,
        ),
        (
            "ai-studio-app-run",
            "Run AI applications",
            "",
            "",
            "",
            "ai-studio",
            "ai_applications:run",
            933,
        ),
        (
            "ai-studio-capability-read",
            "View AI capabilities",
            "",
            "",
            "",
            "ai-studio",
            "ai_capabilities:read",
            935,
        ),
        (
            "ai-studio-capability-manage",
            "Manage AI capabilities",
            "",
            "",
            "",
            "ai-studio",
            "ai_capabilities:manage",
            936,
        ),
        (
            "ai-studio-capability-execute",
            "Execute AI capabilities",
            "",
            "",
            "",
            "ai-studio",
            "ai_capabilities:execute",
            937,
        ),
        (
            "ai-studio-trace-read",
            "View runtime traces",
            "",
            "",
            "",
            "ai-studio",
            "ai_runtime:trace:read",
            934,
        ),
        (
            "ai-assets",
            "AI 资产",
            "",
            "",
            "robot",
            "",
            "",
            93,
        ),
        (
            "prompt-library",
            "提示词库",
            "/prompts/library",
            "prompt-library",
            "message",
            "ai-assets",
            "prompt:assets:view",
            931,
        ),
        (
            "prompt-library-manage",
            "管理提示词",
            "",
            "",
            "",
            "prompt-library",
            "prompt:assets:manage",
            9311,
        ),
    ]
    for key, label, path, route_name, icon, parent_key, permission_code, sort_order in tenant_menu_rows:
        if key in RETIRED_AI_ASSETS_MENU_KEYS:
            continue
        conn.execute(
            """
            INSERT INTO menus (
                menu_key, menu_scope, label, menu_type, path, route_name, component, icon,
                parent_key, permission_code, sort_order, is_visible
            )
            SELECT ?, 'tenant', ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE
            WHERE NOT EXISTS (SELECT 1 FROM menus WHERE menu_key = ?)
            """,
            (
                key,
                label,
                DEFAULT_MENU_METADATA[key]["menu_type"],
                path,
                route_name,
                DEFAULT_MENU_METADATA[key]["component"],
                icon,
                parent_key,
                permission_code,
                sort_order,
                key,
            ),
        )


def repair_tenant_rbac_boundaries(conn: Any) -> None:
    conn.execute(
        """
        DELETE FROM tenant_memberships
        WHERE user_id IN (SELECT id FROM users WHERE is_superuser = TRUE)
        """
    )
    conn.execute(
        """
        DELETE FROM user_roles
        WHERE role_id IN (SELECT id FROM roles WHERE role_scope = 'tenant')
          AND user_id IN (
              SELECT u.id
              FROM users u
              JOIN tenants t ON t.id = u.tenant_id
              WHERE t.tenant_key = ?
          )
        """,
        (PLATFORM_TENANT_KEY,),
    )
    platform_role_rows = conn.execute("SELECT id FROM roles WHERE role_scope = 'platform'").fetchall()
    platform_role_ids = [int(row["id"]) for row in platform_role_rows]
    if platform_role_ids:
        placeholders = ",".join(["?"] * len(platform_role_ids))
        conn.execute(
            f"""
            DELETE FROM user_roles
            WHERE role_id IN ({placeholders})
              AND user_id IN (
                  SELECT u.id
                  FROM users u
                  JOIN tenants t ON t.id = u.tenant_id
                  WHERE t.tenant_key <> ?
              )
            """,
            (*platform_role_ids, PLATFORM_TENANT_KEY),
        )

    tenant_admin_role = conn.execute("SELECT id FROM roles WHERE role_key = ?", ("tenant-admin",)).fetchone()
    tenant_member_role = conn.execute("SELECT id FROM roles WHERE role_key = ?", ("tenant-member",)).fetchone()
    if tenant_admin_role:
        conn.execute(
            """
            INSERT INTO user_roles (user_id, role_id)
            SELECT tm.user_id, ?
            FROM tenant_memberships tm
            JOIN users u ON u.id = tm.user_id
            WHERE tm.is_tenant_admin = TRUE
              AND u.is_superuser = FALSE
              AND NOT EXISTS (
                  SELECT 1 FROM user_roles ur
                  WHERE ur.user_id = tm.user_id AND ur.role_id = ?
              )
            """,
            (int(tenant_admin_role["id"]), int(tenant_admin_role["id"])),
        )
    if tenant_member_role:
        conn.execute(
            """
            INSERT INTO user_roles (user_id, role_id)
            SELECT tm.user_id, ?
            FROM tenant_memberships tm
            JOIN users u ON u.id = tm.user_id
            WHERE tm.is_tenant_admin = FALSE
              AND u.is_superuser = FALSE
              AND NOT EXISTS (
                  SELECT 1 FROM user_roles ur
                  WHERE ur.user_id = tm.user_id AND ur.role_id = ?
              )
            """,
            (int(tenant_member_role["id"]), int(tenant_member_role["id"])),
        )


def ensure_role_access_by_key(conn: Any, role_key: str, menu_keys: list[str]) -> None:
    role_row = conn.execute("SELECT id, role_scope FROM roles WHERE role_key = ?", (role_key,)).fetchone()
    if not role_row:
        return
    role_id = int(role_row["id"])
    role_scope = str(role_row["role_scope"] or "platform")
    conn.execute("DELETE FROM role_menus WHERE role_id = ?", (role_id,))
    conn.execute("DELETE FROM role_permissions WHERE role_id = ?", (role_id,))
    for menu_key in menu_keys:
        menu_row = conn.execute(
            "SELECT id, permission_code FROM menus WHERE menu_key = ? AND menu_scope = ?",
            (menu_key, role_scope),
        ).fetchone()
        if not menu_row:
            continue
        conn.execute(
            """
            INSERT INTO role_menus (role_id, menu_id)
            VALUES (?, ?)
            """,
            (role_id, int(menu_row["id"])),
        )
        permission_code = str(menu_row["permission_code"] or "").strip()
        if not permission_code:
            continue
        permission_row = conn.execute("SELECT id FROM permissions WHERE code = ?", (permission_code,)).fetchone()
        if permission_row:
            conn.execute(
                """
                INSERT INTO role_permissions (role_id, permission_id)
                SELECT ?, ?
                WHERE NOT EXISTS (
                    SELECT 1 FROM role_permissions WHERE role_id = ? AND permission_id = ?
                )
                """,
                (role_id, int(permission_row["id"]), role_id, int(permission_row["id"])),
            )


def ensure_role_menus_by_key(conn: Any, role_key: str, menu_keys: list[str]) -> None:
    role_row = conn.execute("SELECT id, role_scope FROM roles WHERE role_key = ?", (role_key,)).fetchone()
    if not role_row:
        return
    role_id = int(role_row["id"])
    role_scope = str(role_row["role_scope"] or "platform")
    for menu_key in menu_keys:
        menu_row = conn.execute(
            "SELECT id, permission_code FROM menus WHERE menu_key = ? AND menu_scope = ?",
            (str(menu_key).strip(), role_scope),
        ).fetchone()
        if not menu_row:
            continue
        menu_id = int(menu_row["id"])
        conn.execute(
            """
            INSERT INTO role_menus (role_id, menu_id)
            SELECT ?, ?
            WHERE NOT EXISTS (
                SELECT 1 FROM role_menus WHERE role_id = ? AND menu_id = ?
            )
            """,
            (role_id, menu_id, role_id, menu_id),
        )
        permission_code = str(menu_row["permission_code"] or "").strip()
        if permission_code:
            ensure_role_permissions_by_code(conn, role_key, [permission_code])


def ensure_role_permissions_by_code(conn: Any, role_key: str, permission_codes: list[str]) -> None:
    role_row = conn.execute("SELECT id FROM roles WHERE role_key = ?", (role_key,)).fetchone()
    if not role_row:
        return
    role_id = int(role_row["id"])
    for permission_code in permission_codes:
        normalized = str(permission_code).strip()
        if not normalized:
            continue
        permission_row = conn.execute("SELECT id FROM permissions WHERE code = ?", (normalized,)).fetchone()
        if not permission_row:
            continue
        permission_id = int(permission_row["id"])
        conn.execute(
            """
            INSERT INTO role_permissions (role_id, permission_id)
            SELECT ?, ?
            WHERE NOT EXISTS (
                SELECT 1 FROM role_permissions WHERE role_id = ? AND permission_id = ?
            )
            """,
            (role_id, permission_id, role_id, permission_id),
        )


def ensure_tenant_default_roles(conn: Any) -> None:
    now = now_iso()
    role_rows = [
        ("tenant-admin", "Tenant Administrator", "Manage current tenant members and API keys", TENANT_ADMIN_MENU_KEYS),
        ("tenant-member", "Tenant Member", "Use tenant business features", TENANT_MEMBER_MENU_KEYS),
    ]
    for role_key, name, description, menu_keys in role_rows:
        existing_role = conn.execute("SELECT id FROM roles WHERE role_key = ?", (role_key,)).fetchone()
        is_new_role = existing_role is None
        conn.execute(
            """
            INSERT INTO roles (role_key, name, description, is_system, role_scope, create_time, update_time)
            SELECT ?, ?, ?, TRUE, 'tenant', ?, ?
            WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_key = ?)
            """,
            (role_key, name, description, now, now, role_key),
        )
        conn.execute(
            """
            UPDATE roles
            SET role_scope = 'tenant'
            WHERE role_key = ?
            """,
            (role_key,),
        )
        if is_new_role:
            ensure_role_access_by_key(conn, role_key, menu_keys)
        if role_key == "tenant-admin":
            ensure_role_menus_by_key(conn, role_key, TENANT_MESSAGING_MENU_KEYS)
            ensure_role_menus_by_key(conn, role_key, TENANT_LLM_MENU_KEYS)
            ensure_role_menus_by_key(conn, role_key, TENANT_CRON_MENU_KEYS)
            ensure_role_menus_by_key(conn, role_key, TENANT_FILE_MENU_KEYS)
            ensure_role_menus_by_key(conn, role_key, TENANT_BASIC_DATA_MENU_KEYS)
            ensure_role_menus_by_key(conn, role_key, TENANT_AI_ASSETS_MENU_KEYS)
            ensure_role_menus_by_key(conn, role_key, TENANT_ORGANIZATION_MENU_KEYS)
            ensure_role_permissions_by_code(conn, role_key, TENANT_ADMIN_EXTRA_PERMISSION_CODES)

    admin_role = conn.execute("SELECT id FROM roles WHERE role_key = ?", (DEFAULT_ROLE_KEY,)).fetchone()
    has_platform_user = False
    if admin_role:
        has_platform_user = bool(
            conn.execute(
                """
                SELECT 1
                FROM user_roles ur
                JOIN users u ON u.id = ur.user_id
                JOIN tenants t ON t.id = u.tenant_id
                WHERE ur.role_id = ?
                  AND t.tenant_key = ?
                LIMIT 1
                """,
                (int(admin_role["id"]), PLATFORM_TENANT_KEY),
            ).fetchone()
        )
    if admin_role:
        role_id = int(admin_role["id"])
        conn.execute(
            """
            UPDATE roles
            SET role_scope = 'platform'
            WHERE id = ?
            """,
            (role_id,),
        )
        if not has_platform_user:
            conn.execute("DELETE FROM role_menus WHERE role_id = ?", (role_id,))
            conn.execute("DELETE FROM role_permissions WHERE role_id = ?", (role_id,))
            conn.execute(
                """
                INSERT INTO role_menus (role_id, menu_id)
                SELECT ?, id FROM menus WHERE menu_scope = 'platform'
                """,
                (role_id,),
            )
            conn.execute(
                """
                INSERT INTO role_permissions (role_id, permission_id)
                SELECT ?, id FROM permissions
                """,
                (role_id,),
            )


def initialize_auth_storage(conn: Any) -> None:
    if backend_name(conn) == "postgres":
        conn.execute("SELECT pg_advisory_xact_lock(?)", (7183001,))
        ensure_auth_schema(conn)
        ensure_platform_tenant(conn)
        ensure_default_tenant(conn)
        ensure_default_admin(conn)
        ensure_default_rbac(conn)
        return
    if backend_name(conn) == "mysql":
        conn.execute("SELECT GET_LOCK(?, ?)", ("ops_admin_identity_init", 30))
        try:
            ensure_auth_schema(conn)
            ensure_platform_tenant(conn)
            ensure_default_tenant(conn)
            ensure_default_admin(conn)
            ensure_default_rbac(conn)
        finally:
            conn.execute("SELECT RELEASE_LOCK(?)", ("ops_admin_identity_init",))
        return
    with _auth_schema_lock:
        ensure_auth_schema(conn)
        ensure_platform_tenant(conn)
        ensure_default_tenant(conn)
        ensure_default_admin(conn)
        ensure_default_rbac(conn)


def require_auth_ready(conn: Any) -> None:
    try:
        platform_row = conn.execute(
            "SELECT id FROM tenants WHERE tenant_key = ?",
            (PLATFORM_TENANT_KEY,),
        ).fetchone()
        default_row = conn.execute(
            "SELECT id FROM tenants WHERE tenant_key = ?",
            (DEFAULT_TENANT_KEY,),
        ).fetchone()
        admin_row = conn.execute(
            """
            SELECT u.id
            FROM users u
            JOIN tenants t ON t.id = u.tenant_id
            WHERE t.tenant_key = ?
              AND u.username = ?
              AND u.is_superuser = TRUE
            LIMIT 1
            """,
            (PLATFORM_TENANT_KEY, default_admin_username()),
        ).fetchone()
        conn.execute("SELECT 1 FROM roles LIMIT 1").fetchone()
        conn.execute("SELECT 1 FROM permissions LIMIT 1").fetchone()
        conn.execute("SELECT 1 FROM menus LIMIT 1").fetchone()
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"identity storage is not initialized; run `{AUTH_INIT_COMMAND}`",
        ) from exc
    if not platform_row or not default_row or not admin_row:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"identity storage is not initialized; run `{AUTH_INIT_COMMAND}`",
        )


def row_to_api_key(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": int(row["id"]),
        "tenant_id": int(row.get("tenant_id", 0) or 0),
        "name": str(row.get("name", "")),
        "prefix": str(row.get("prefix", "")),
        "is_active": bool(row.get("is_active", True)),
        "creator": str(row.get("creator", "") or ""),
        "creator_id": row.get("creator_id"),
        "create_time": str(row.get("create_time", "") or ""),
        "editor": str(row.get("editor", "") or ""),
        "editor_id": row.get("editor_id"),
        "update_time": str(row.get("update_time", "") or ""),
    }


def row_to_menu(row: dict[str, Any]) -> dict[str, Any]:
    key = str(row.get("menu_key", ""))
    return {
        "id": int(row.get("id", 0) or 0),
        "key": key,
        "label": str(row.get("label", "")),
        "menu_scope": str(row.get("menu_scope", "") or "tenant"),
        "menu_type": str(row.get("menu_type", "") or "page"),
        "path": str(row.get("path", "") or ""),
        "route_name": str(row.get("route_name", "") or ""),
        "component": str(row.get("component", "") or ""),
        "icon": str(row.get("icon", "") or ""),
        "parent_key": str(row.get("parent_key", "") or ""),
        "permission_code": str(row.get("permission_code", "") or ""),
        "sort_order": int(row.get("sort_order", 0) or 0),
        "is_visible": bool(row.get("is_visible", True)),
        "children": [],
    }


def build_menu_tree(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    menus = [
        row_to_menu(row)
        for row in rows
        if bool(row.get("is_visible", True)) and str(row.get("menu_type", "") or "page") != "action"
    ]
    by_key = {menu["key"]: menu for menu in menus}
    roots: list[dict[str, Any]] = []
    for menu in menus:
        parent_key = menu["parent_key"]
        if parent_key and parent_key in by_key:
            by_key[parent_key]["children"].append(menu)
        else:
            roots.append(menu)
    return roots
