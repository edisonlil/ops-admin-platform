"""Object storage adapters."""
