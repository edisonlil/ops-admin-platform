"""File management bounded context."""
