"""System domain primitives."""
