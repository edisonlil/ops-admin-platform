#!/bin/bash
set -e

DEPLOY_DIR="/opt/ops-admin"
REQUIRED_DIRS=("api" "packages" "dist")

echo "Starting deployment..."

# Safety check 1: Verify we're in the correct deployment directory
if [ ! -d "$DEPLOY_DIR" ]; then
    echo "ERROR: Deployment directory $DEPLOY_DIR does not exist"
    exit 1
fi

cd "$DEPLOY_DIR"
echo "Working directory: $(pwd)"

# Safety check 2: Verify required directories exist
echo "Verifying deployment package..."
MISSING=()
for d in "${REQUIRED_DIRS[@]}"; do
    if [ ! -d "$d" ]; then
        MISSING+=("$d")
        echo "  Missing: $d"
    else
        echo "  Found: $d"
    fi
done
if [ ${#MISSING[@]} -gt 0 ]; then
    echo "ERROR: Missing required directories: ${MISSING[*]}"
    ls -la
    exit 1
fi

# Safety check 3: Verify Dockerfile exists (should be in root)
if [ ! -f "Dockerfile" ]; then
    echo "ERROR: Dockerfile not found"
    ls *.txt *.yml 2>/dev/null || true
    exit 1
fi

# Safety check 4: Verify Dockerfile has multi-stage build
if ! grep -q "^FROM" Dockerfile; then
    echo "ERROR: Dockerfile appears invalid (no FROM instruction)"
    exit 1
fi

# Stop existing container
echo "Stopping existing container..."
docker-compose down 2>/dev/null || true

# Build image
echo "Building Docker image..."
docker build -t ops-admin:latest .

# Verify image was built successfully
if ! docker image inspect ops-admin:latest > /dev/null 2>&1; then
    echo "ERROR: Docker image build failed"
    exit 1
fi

# Start container
echo "Starting container..."
docker-compose up -d

# Verify container is running
sleep 3
if ! docker ps | grep -q "ops-admin"; then
    echo "ERROR: Container failed to start"
    exit 1
fi

echo "Build completed. Cleaning up source code..."

# Safety check 5: Verify we're not in root or home directory
if [ "$DEPLOY_DIR" = "/" ] || [ "$DEPLOY_DIR" = "/home" ] || [ "$DEPLOY_DIR" = "$HOME" ]; then
    echo "ERROR: Safety check failed - refusing to delete in root/home directory"
    exit 1
fi

# Safety check 6: Verify critical files exist (prevent empty directory deletion)
if [ ! -f "docker-compose.yml" ]; then
    echo "ERROR: docker-compose.yml missing - aborting cleanup"
    exit 1
fi

# Safety check 7: Verify expected directories still exist before cleanup
if [ ! -d "api" ] || [ ! -d "packages" ]; then
    echo "ERROR: Directory structure mismatch - aborting cleanup"
    exit 1
fi

# Clean up source code (keep only runtime files)
echo "Removing source code directories..."
rm -rf api packages scripts *.txt Dockerfile .dockerignore 2>/dev/null || true

# Verify cleanup was successful (directories should not exist)
if [ -d "api" ] || [ -d "packages" ]; then
    echo "WARNING: Source directories still exist, manual cleanup required"
else
    echo "Source code cleaned up successfully"
fi

echo ""
echo "Deployment completed!"
echo "URL: http://localhost:8000"
docker ps | grep ops-admin
