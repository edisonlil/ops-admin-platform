#!/bin/bash
set -e

DEPLOY_DIR="/opt/ops-admin"
CONTAINER_NAME="ops-admin-backend-default"
REQUIRED_DIRS=("api" "packages" "dist")

echo "Starting deployment..."

# Safety check 1: Verify we're in the correct deployment directory
if [ ! -d "$DEPLOY_DIR" ]; then
    echo "ERROR: Deployment directory $DEPLOY_DIR does not exist"
    exit 1
fi

cd "$DEPLOY_DIR"
echo "Working directory: $(pwd)"

# Safety check 2: Verify required directories exist
echo "Verifying deployment package..."
ls -la

MISSING=()
for d in "${REQUIRED_DIRS[@]}"; do
    if [ ! -d "$d" ]; then
        MISSING+=("$d")
        echo "  Missing: $d"
    else
        echo "  Found: $d"
    fi
done

# Debug: list dist contents
if [ -d "dist" ]; then
    echo "  dist/ contents:"
    ls -la dist/ | head -10
fi
if [ ${#MISSING[@]} -gt 0 ]; then
    echo "ERROR: Missing required directories: ${MISSING[*]}"
    ls -la
    exit 1
fi

# Safety check 3: Verify Dockerfile exists (should be in root)
if [ ! -f "Dockerfile" ]; then
    echo "ERROR: Dockerfile not found"
    ls *.txt *.yml 2>/dev/null || true
    exit 1
fi

# Safety check 4: Verify Dockerfile has multi-stage build
if ! grep -q "^FROM" Dockerfile; then
    echo "ERROR: Dockerfile appears invalid (no FROM instruction)"
    exit 1
fi

# Create .dockerignore to allow dist/ (scaffold's .dockerignore excludes it)
echo "Creating .dockerignore to allow dist/..."
cat > .dockerignore << 'DOCKERIGNORE_EOF'
# Allow dist/ for deployment
!dist/**
!dist/

# Exclude other large directories
node_modules/
__pycache__/
*.pyc
.venv/
.vscode/
.idea/
.git/
DOCKERIGNORE_EOF

# Verify dist exists
echo "Verifying dist/ exists..."
if [ ! -d "dist" ]; then
    echo "ERROR: dist/ directory not found!"
    ls -la | grep dist || echo "dist not in ls"
    exit 1
fi
echo "dist/ found, contents:"
ls -la dist/ | head -5

# Stop existing container
echo "Stopping existing container..."
docker-compose down 2>/dev/null || true

# Remove existing container with the same name to avoid name conflict
if [ -n "$CONTAINER_NAME" ]; then
    EXISTING_IDS=$(docker ps -aq --filter "name=^/$CONTAINER_NAME$")
    if [ -n "$EXISTING_IDS" ]; then
        echo "Removing existing container: $CONTAINER_NAME"
        echo "$EXISTING_IDS" | xargs -r docker rm -f
    fi
fi

# Build image
echo "Building Docker image..."
docker build -t ops-admin:latest . 2>&1 | tee /tmp/ops-admin-build.log
if [ ${PIPESTATUS[0]} -ne 0 ]; then
    echo "ERROR: docker build failed. Showing /tmp/ops-admin-build.log"
    tail -n 200 /tmp/ops-admin-build.log
    exit 1
fi

# Verify image was built successfully
if ! docker image inspect ops-admin:latest > /dev/null 2>&1; then
    echo "ERROR: Docker image build failed"
    exit 1
fi

# Start container
echo "Starting container..."
docker-compose up -d

# Verify container is running
sleep 3
if ! docker ps | grep -q "$CONTAINER_NAME"; then
    echo "ERROR: Container failed to start"
    exit 1
fi

echo "Build completed. Cleaning up source code..."

# Safety check 5: Verify we're not in root or home directory
if [ "$DEPLOY_DIR" = "/" ] || [ "$DEPLOY_DIR" = "/home" ] || [ "$DEPLOY_DIR" = "$HOME" ]; then
    echo "ERROR: Safety check failed - refusing to delete in root/home directory"
    exit 1
fi

# Safety check 6: Verify at least Dockerfile exists (critical for build)
if [ ! -f "Dockerfile" ]; then
    echo "ERROR: Dockerfile missing - cannot build image"
    exit 1
fi

# Safety check 7: Verify expected directories still exist before cleanup
if [ ! -d "api" ] || [ ! -d "packages" ]; then
    echo "ERROR: Directory structure mismatch - aborting cleanup"
    exit 1
fi

# Clean up source code (keep only runtime files and config)
echo "Removing source code directories..."
rm -rf api packages scripts *.txt Dockerfile .dockerignore ops-deploy.tar.gz deploy.sh 2>/dev/null || true

# Verify cleanup was successful (directories should not exist)
if [ -d "api" ] || [ -d "packages" ]; then
    echo "WARNING: Source directories still exist, manual cleanup required"
else
    echo "Source code cleaned up successfully"
fi

echo ""
echo "Deployment completed!"
if [ -n "$CONTAINER_NAME" ]; then
    docker ps | grep "$CONTAINER_NAME"
fi
